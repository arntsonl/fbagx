BmpToZlibGc Compression Tool
     v1.1 by Cthulhu32
---------------------------
 The BmpToZlibGc compression tool is 100% based off of BmpToGc.exe. 
It was created in hopes of replicating the Snes9x-Gx compressed texture
embedded into the dol/elf. By combining the original BmpToGc with the
zlib compression, the output gives you a struct you can use in your elf.
---------------------------

October 14th, 2008 ---
o First version of the tool.
o One known bug, dragging BMPs onto the exe in Windows will cause weird names
o (Example coming soon :D )

---------------------------

Any questions/comments/etc. can be sent to :
   cthulhu32 at gmail dot com
