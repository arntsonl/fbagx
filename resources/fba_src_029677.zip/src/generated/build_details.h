#define BUILD_TIME 15:13:52
#define BUILD_DATE Apr  4 2008
#define BUILD_CHAR Unicode
#define BUILD_CPU  i686
#define BUILD_COMP Visual C++ 9.0
#ifndef _MSC_VER
 #define _MSC_VER  1500
#endif
