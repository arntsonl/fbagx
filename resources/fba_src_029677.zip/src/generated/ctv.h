#define CU_MASK  (0)

#define CU_BPP   (2)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo208____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo208__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo208_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo208_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo216____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo216__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo216_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo216_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo216r___()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo216r_f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo216rc__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo216rcf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo232____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo232__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo232_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo232_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#define CU_BPP   (3)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo308____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo308__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo308_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo308_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo316____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo316__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo316_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo316_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo316r___()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo316r_f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo316rc__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo316rcf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo332____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo332__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo332_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo332_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#define CU_BPP   (4)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo408____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo408__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo408_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo408_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo416____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo416__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo416_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo416_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo416r___()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo416r_f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo416rc__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo416rcf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo432____()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo432__f_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo432_c__()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo432_cf_()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#undef  CU_MASK

#define CU_MASK  (1)

#define CU_BPP   (2)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo208___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo208__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo208_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo208_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo216___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo216__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo216_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo216_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo232___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo232__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo232_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo232_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#define CU_BPP   (3)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo308___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo308__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo308_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo308_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo316___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo316__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo316_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo316_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo332___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo332__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo332_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo332_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#define CU_BPP   (4)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo408___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo408__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo408_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo408_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo416___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo416__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo416_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo416_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo432___m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo432__fm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo432_c_m()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo432_cfm()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#undef  CU_MASK

#define CU_MASK  (2)

#define CU_BPP   (2)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo208___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo208__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo208_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo208_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo216___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo216__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo216_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo216_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo232___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo232__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo232_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo232_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#define CU_BPP   (3)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo308___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo308__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo308_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo308_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo316___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo316__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo316_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo316_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo332___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo332__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo332_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo332_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#define CU_BPP   (4)

#define CU_SIZE  (8)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo408___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo408__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo408_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo408_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (16)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo416___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo416__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo416_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo416_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#define CU_SIZE  (32)

#define CU_ROWS  (0)

#define CU_CARE  (0)
#define CU_FLIPX (0)
static int CtvDo432___b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo432__fb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
static int CtvDo432_c_b()
#include "ctv_do.h"
#undef  CU_FLIPX
#define CU_FLIPX (1)
static int CtvDo432_cfb()
#include "ctv_do.h"
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#define CU_ROWS  (1)

#define CU_CARE  (0)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#define CU_CARE  (1)
#define CU_FLIPX (0)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#define CU_FLIPX (1)
// Invalid combination of capabilities.
#undef  CU_FLIPX
#undef  CU_CARE

#undef  CU_ROWS

#undef  CU_SIZE

#undef  CU_BPP

#undef  CU_MASK



// Filler function
static int CtvDo_______() { return 0; }



// Lookup table for 2 bpp
static CtvDoFn CtvDo2[0x20]={
CtvDo208____,CtvDo208__f_,CtvDo208_c__,CtvDo208_cf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo216____,CtvDo216__f_,CtvDo216_c__,CtvDo216_cf_,
CtvDo216r___,CtvDo216r_f_,CtvDo216rc__,CtvDo216rcf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo232____,CtvDo232__f_,CtvDo232_c__,CtvDo232_cf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};
// Lookup table for 3 bpp
static CtvDoFn CtvDo3[0x20]={
CtvDo308____,CtvDo308__f_,CtvDo308_c__,CtvDo308_cf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo316____,CtvDo316__f_,CtvDo316_c__,CtvDo316_cf_,
CtvDo316r___,CtvDo316r_f_,CtvDo316rc__,CtvDo316rcf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo332____,CtvDo332__f_,CtvDo332_c__,CtvDo332_cf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};
// Lookup table for 4 bpp
static CtvDoFn CtvDo4[0x20]={
CtvDo408____,CtvDo408__f_,CtvDo408_c__,CtvDo408_cf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo416____,CtvDo416__f_,CtvDo416_c__,CtvDo416_cf_,
CtvDo416r___,CtvDo416r_f_,CtvDo416rc__,CtvDo416rcf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo432____,CtvDo432__f_,CtvDo432_c__,CtvDo432_cf_,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};
// Lookup table for 2 bpp with Sprite Masking
static CtvDoFn CtvDo2m[0x20]={
CtvDo208___m,CtvDo208__fm,CtvDo208_c_m,CtvDo208_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo216___m,CtvDo216__fm,CtvDo216_c_m,CtvDo216_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo232___m,CtvDo232__fm,CtvDo232_c_m,CtvDo232_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};
// Lookup table for 3 bpp with Sprite Masking
static CtvDoFn CtvDo3m[0x20]={
CtvDo308___m,CtvDo308__fm,CtvDo308_c_m,CtvDo308_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo316___m,CtvDo316__fm,CtvDo316_c_m,CtvDo316_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo332___m,CtvDo332__fm,CtvDo332_c_m,CtvDo332_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};
// Lookup table for 4 bpp with Sprite Masking
static CtvDoFn CtvDo4m[0x20]={
CtvDo408___m,CtvDo408__fm,CtvDo408_c_m,CtvDo408_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo416___m,CtvDo416__fm,CtvDo416_c_m,CtvDo416_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo432___m,CtvDo432__fm,CtvDo432_c_m,CtvDo432_cfm,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};
// Lookup table for 2 bpp with BgHi
static CtvDoFn CtvDo2b[0x20]={
CtvDo208___b,CtvDo208__fb,CtvDo208_c_b,CtvDo208_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo216___b,CtvDo216__fb,CtvDo216_c_b,CtvDo216_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo232___b,CtvDo232__fb,CtvDo232_c_b,CtvDo232_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};
// Lookup table for 3 bpp with BgHi
static CtvDoFn CtvDo3b[0x20]={
CtvDo308___b,CtvDo308__fb,CtvDo308_c_b,CtvDo308_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo316___b,CtvDo316__fb,CtvDo316_c_b,CtvDo316_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo332___b,CtvDo332__fb,CtvDo332_c_b,CtvDo332_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};
// Lookup table for 4 bpp with BgHi
static CtvDoFn CtvDo4b[0x20]={
CtvDo408___b,CtvDo408__fb,CtvDo408_c_b,CtvDo408_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo416___b,CtvDo416__fb,CtvDo416_c_b,CtvDo416_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
CtvDo432___b,CtvDo432__fb,CtvDo432_c_b,CtvDo432_cfb,
CtvDo_______,CtvDo_______,CtvDo_______,CtvDo_______,
};


// Current BPP:
CtvDoFn CtvDoX[0x20];
CtvDoFn CtvDoXM[0x20];
CtvDoFn CtvDoXB[0x20];


