#define ISOPAQUE 0

// 16-bit rendering functions.
#define BPP 16

#define DOCLIP 0
#define XZOOM 0
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 1
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 2
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 3
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 4
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 5
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 6
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 7
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 8
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 9
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 10
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 11
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 12
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 13
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 14
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 15
#include "neo_sprite_render.h"
#undef XZOOM
#undef DOCLIP
#define DOCLIP 1
#define XZOOM 0
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 1
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 2
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 3
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 4
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 5
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 6
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 7
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 8
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 9
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 10
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 11
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 12
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 13
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 14
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 15
#include "neo_sprite_render.h"
#undef XZOOM
#undef DOCLIP
#undef BPP

// 24-bit rendering functions.
#define BPP 24

#define DOCLIP 0
#define XZOOM 0
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 1
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 2
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 3
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 4
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 5
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 6
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 7
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 8
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 9
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 10
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 11
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 12
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 13
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 14
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 15
#include "neo_sprite_render.h"
#undef XZOOM
#undef DOCLIP
#define DOCLIP 1
#define XZOOM 0
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 1
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 2
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 3
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 4
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 5
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 6
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 7
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 8
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 9
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 10
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 11
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 12
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 13
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 14
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 15
#include "neo_sprite_render.h"
#undef XZOOM
#undef DOCLIP
#undef BPP

// 32-bit rendering functions.
#define BPP 32

#define DOCLIP 0
#define XZOOM 0
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 1
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 2
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 3
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 4
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 5
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 6
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 7
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 8
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 9
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 10
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 11
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 12
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 13
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 14
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 15
#include "neo_sprite_render.h"
#undef XZOOM
#undef DOCLIP
#define DOCLIP 1
#define XZOOM 0
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 1
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 2
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 3
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 4
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 5
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 6
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 7
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 8
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 9
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 10
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 11
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 12
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 13
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 14
#include "neo_sprite_render.h"
#undef XZOOM
#define XZOOM 15
#include "neo_sprite_render.h"
#undef XZOOM
#undef DOCLIP
#undef BPP

#undef ISOPAQUE

#include "neo_sprite_func_table.h"
