#include <windows.h>
#include <richedit.h>

#ifndef IDC_STATIC
 #define IDC_STATIC (-1)
#endif
