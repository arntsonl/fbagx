extern void TC0140SYTPortWrite(UINT8 Data);
extern UINT8 TC0140SYTCommRead();
extern void TC0140SYTCommWrite(UINT8 Data);
extern void TC0140SYTSlavePortWrite(UINT8 Data);
extern UINT8 TC0140SYTSlaveCommRead();
extern void TC0140SYTSlaveCommWrite(UINT8 Data);
extern void TC0140SYTReset();
extern void TC0140SYTExit();
extern void TC0140SYTScan(int nAction);
