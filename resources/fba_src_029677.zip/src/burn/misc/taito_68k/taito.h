/*
Part of FBAs Taito 68k hardware drivers
Credits: Mame team, Raine team
Coding by KEV, with help from Treble Winner and Jan_Klaassen
*/

#ifndef __Taito_H__
#define __Taito_H__
#include "burnint.h"
#include "burn_ym2151.h"
#include "taito_gfx.h"
#include "snd_tc0140.h"
#include "rain_chip.h"
extern int rCyclesDone[3];
#endif




