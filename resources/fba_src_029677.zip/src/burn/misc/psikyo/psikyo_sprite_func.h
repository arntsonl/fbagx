#define ROT 0
#define BPP 16
#define ROWSCROLL 0

#define TRANS 0

#define ZOOM 0

#define FLIP 0

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 1

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 2

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 3

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP

#undef ZOOM
#define ZOOM 1

#define FLIP 0

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 1

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 2

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 3

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP

#undef ZOOM

#undef TRANS
#define TRANS 15

#define ZOOM 0

#define FLIP 0

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 1

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 2

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 3

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP

#undef ZOOM
#define ZOOM 1

#define FLIP 0

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 1

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 2

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP
#define FLIP 3

#define ZBUFFER 0

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 1

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 2

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER
#define ZBUFFER 3

#define DOCLIP 0
#include "psikyo_render.h"
#undef DOCLIP
#define DOCLIP 1
#include "psikyo_render.h"
#undef DOCLIP

#undef ZBUFFER

#undef FLIP

#undef ZOOM

#undef TRANS

#undef ROWSCROLL
#undef ROT
#undef BPP

// no zbuffer/no clip, no zbuffer/clip, read zbuffer/no clip, read zbuffer/clip, write zbuffer/no clip, write zbuffer/clip, read/write zbuffer/no clip, read/write zbuffer/clip,
static RenderSpriteFunction RenderSprite[] = {
	// Transparency 15, no zooming
	&RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_NOCLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_CLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_NOCLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_CLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_NOCLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_CLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_NOCLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_NOCLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_CLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_NOCLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_CLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_NOCLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_CLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_NOCLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_CLIP,
	// Transparency 15, zooming
	&RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_NOCLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_CLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_NOCLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_CLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_NOCLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_CLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_NOCLIP, &RenderTile16_TRANS15_NOFLIP_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPX_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_CLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_NOCLIP,  &RenderTile16_TRANS15_FLIPY_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_NOCLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_CLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_NOCLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_CLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_NOCLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_CLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_NOCLIP, &RenderTile16_TRANS15_FLIPXY_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_CLIP,

	// Transparency 0, no zooming
	&RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_NOCLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_CLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_NOCLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_CLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_NOCLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_CLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_NOCLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_NOCLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_NOZBUFFER_CLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_NOCLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_RZBUFFER_CLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_NOCLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_WZBUFFER_CLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_NOCLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_NOZOOM_RWZBUFFER_CLIP,
	// Transparency 0, zooming
	&RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_NOCLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_CLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_NOCLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_CLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_NOCLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_CLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_NOCLIP, &RenderTile16_TRANS0_NOFLIP_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPX_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_CLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_NOCLIP,  &RenderTile16_TRANS0_FLIPY_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_CLIP,
	&RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_NOCLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_ZOOM_NOZBUFFER_CLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_NOCLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_ZOOM_RZBUFFER_CLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_NOCLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_ZOOM_WZBUFFER_CLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_NOCLIP, &RenderTile16_TRANS0_FLIPXY_ROT0_NOROWSCROLL_ZOOM_RWZBUFFER_CLIP,
};
