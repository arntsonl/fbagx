void VidSFreeVidImage();
int VidSAllocVidImage();
