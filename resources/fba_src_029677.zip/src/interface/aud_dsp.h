// dsp.cpp
int DspInit();
int DspExit();
int DspDo(short* Wave, int nCount);
